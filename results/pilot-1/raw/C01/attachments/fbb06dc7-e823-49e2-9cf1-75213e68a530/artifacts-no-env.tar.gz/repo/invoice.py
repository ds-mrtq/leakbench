def total_cents(items):
    return sum(item["cents"] * item["quantity"] for item in items)
