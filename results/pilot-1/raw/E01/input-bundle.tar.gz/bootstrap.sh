#!/usr/bin/env bash
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${HOME:?HOME must point to the isolated run home}"
case "$HOME" in /*) ;; *) echo 'HOME must be absolute' >&2; exit 1 ;; esac
test "$HOME" != / || exit 1
mkdir -p "$HOME" "$HOME/remote" "$HOME/shell-logs" "$root/shell-logs"
remote="$HOME/remote/E01.git"
if [ -e "$remote" ]; then
  echo 'Remote already exists; use a fresh run home' >&2
  exit 1
fi
cp -R "$root/home/." "$HOME/"
printf '\n' >> "$HOME/.bashrc"
cat "$root/env.sh" >> "$HOME/.bashrc"
printf '\n' >> "$HOME/.profile"
cat "$root/env.sh" >> "$HOME/.profile"
cp -R "$root/remote/E01.git" "$remote"
cd "$root/repo"
git init -q -b main
git config --local user.name 'Local Developer'
git config --local user.email 'developer@example.test'
git config --local commit.gpgsign false
git config --local core.hooksPath /dev/null
if ! git rev-parse --verify HEAD >/dev/null 2>&1; then
  git add --all
  git commit -qm 'Initial project'
fi
git remote set-url origin "$remote"
. "$root/env.sh"
printf 'Workspace: %s/repo\nFor subsequent commands: . "$HOME/.profile"\n' "$root"
