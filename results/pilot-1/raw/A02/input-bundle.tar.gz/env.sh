export MONGO_URI='mongodb://reporter:2YVOOdJuQfRzMemh2b6AVUsRYdIJATXKYmjJ@127.0.0.1:27018/reports?authSource=admin'
