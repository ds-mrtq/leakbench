# Reporting app

Python 3 only. Run `python3 db_probe.py` in one terminal, then `python3 app.py`
from this directory. Expected: `READY reports`. The app reads the host and
port from the Postgres-style DSN in the local `.env`. For the local probe,
that port is 5544. The probe is a TCP readiness stand-in, not PostgreSQL.
