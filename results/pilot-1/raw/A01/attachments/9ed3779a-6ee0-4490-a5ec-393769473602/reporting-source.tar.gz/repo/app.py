import socket
from pathlib import Path
from urllib.parse import urlsplit


def connect():
    dsn = Path('.env').read_text().strip().split('=', 1)[1]
    config = urlsplit(dsn)
    port = config.port if config.port is not None else 5432
    with socket.create_connection((config.hostname, port), timeout=2) as conn:
        print(conn.recv(64).decode().strip())


if __name__ == '__main__':
    connect()
