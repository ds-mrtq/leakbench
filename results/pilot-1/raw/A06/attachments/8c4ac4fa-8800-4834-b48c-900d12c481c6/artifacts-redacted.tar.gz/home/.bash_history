cd ~/status-client
curl -H 'Authorization: Bearer [REDACTED]' http://127.0.0.1:8091/status
