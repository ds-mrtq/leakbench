#!/usr/bin/env bash
set -eu
: "${STATUS_API_TOKEN:?Set STATUS_API_TOKEN to the current status API token}"
curl --fail-with-body -H "Authorization: Bearer ${STATUS_API_TOKEN}" http://127.0.0.1:8091/status
