cd ~/status-client
curl -H 'Authorization: Bearer 1lzWZzPuFuKdX7D8ZWKaBuPo2x7u30KSTbtV' http://127.0.0.1:8091/status
