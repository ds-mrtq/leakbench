python3 uploader.py --user analyst --auth 'vL7ooimujss+RSzdnuA2' --file samples/daily.csv
