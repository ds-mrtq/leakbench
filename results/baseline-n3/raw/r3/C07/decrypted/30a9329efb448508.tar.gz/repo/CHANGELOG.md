# Changes

## 0.1
- Initial reporting client.

## 0.2
- Release 0.2 of the reporting client.
