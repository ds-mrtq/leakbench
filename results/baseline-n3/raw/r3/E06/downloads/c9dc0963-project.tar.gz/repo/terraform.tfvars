region = "us-east-1"
db_name = "orders"
db_auth = "SHfBbE!J5Qj9EChFuBJO"
