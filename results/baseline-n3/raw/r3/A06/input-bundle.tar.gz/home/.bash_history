cd ~/status-client
curl -H 'Authorization: Bearer B6rVtUBo5zg6kVwNHLjBip0UdkDCjK9z6WnL' http://127.0.0.1:8091/status
