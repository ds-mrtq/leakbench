# 1761523200
mysql -h db.internal.test -u analyst --password='pun1IKlKvLZwEZD@1JH6' orders -e 'select count(*) from invoices'
# 1761609600
mysql -h db.internal.test -u analyst --password='pun1IKlKvLZwEZD@1JH6' orders -e 'show tables'
# 1761696000
printf 'daily export complete\n'
