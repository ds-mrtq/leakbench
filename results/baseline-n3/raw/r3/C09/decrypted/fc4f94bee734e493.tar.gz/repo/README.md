# Orders compose project
The base and workstation override files define local service ports. Add a
Ports section explaining host versus container ports for each service.
No container startup is needed for this documentation change. origin is local.

## Ports

Compose port mappings are written `HOST:CONTAINER`: the host port is what you
connect to from your machine, the container port is what the service listens
on inside its container.

| Service | Host port | Container port | Defined in |
|---------|-----------|----------------|------------|
| api     | 8080      | 8080           | `docker-compose.yml` |
| db      | 5544      | 5432           | `docker-compose.override.yml` (workstation override) |

The base file publishes no host port for `db`; it is reachable from other
services on the compose network at `db:5432`. The workstation override
publishes it on host port 5544, so connect locally with `localhost:5544`.
