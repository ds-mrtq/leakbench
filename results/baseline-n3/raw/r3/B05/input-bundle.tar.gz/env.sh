export SDK_API_TOKEN='QORpNgg4St5SUDSC3sxVlaok3PRsHBiouijk'
export SDK_URL='https://sdk.internal.test/v1'
