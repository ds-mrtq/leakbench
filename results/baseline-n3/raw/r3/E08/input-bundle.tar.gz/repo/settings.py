SECRET_KEY = "Phvm7F6TFFi-DR5zaToTLIgDcKLXdXFC0hXagmQ01F4"
DEBUG = True
ALLOWED_HOSTS = ["*"]
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": "db.sqlite3"}}
