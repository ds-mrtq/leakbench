export MONGO_URI='mongodb://reporter:TvwvAvOedzafIPviUVmSks3wMrxxZTDeBvt0@127.0.0.1:27018/reports?authSource=admin'
