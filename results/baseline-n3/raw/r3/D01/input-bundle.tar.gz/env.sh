export PAYMENTS_TOKEN='EF7NBGKMZCA1b7skxoWlVntnEFLMA78PsMtk'
export SESSION_SIGNING_KEY='qaOfAocgPewFoeAvGPNblnnbBM_abcWEFcx_hSeo6d0'
export WORKER_MODE='preview'
export WORKER_REGION='local'
