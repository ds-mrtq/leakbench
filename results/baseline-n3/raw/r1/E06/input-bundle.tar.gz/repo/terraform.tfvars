region = "us-east-1"
db_name = "orders"
db_auth = "prAzreWIcx1sf1Ss%XTZ"
