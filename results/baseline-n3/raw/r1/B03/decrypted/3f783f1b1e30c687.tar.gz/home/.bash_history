python3 uploader.py --user analyst --auth 'JXkt+k36UMuyus8QFH+Q' --file samples/daily.csv
