SECRET_KEY = "DaM77ksTCwx_zq2Rxd1Vl6R_u3hmek8mn_2UVXEK1YQ"
DEBUG = True
ALLOWED_HOSTS = ["*"]
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": "db.sqlite3"}}
