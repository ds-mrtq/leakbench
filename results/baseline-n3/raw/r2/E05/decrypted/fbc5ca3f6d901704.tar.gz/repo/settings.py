import tomllib
from pathlib import Path
def load():
    with Path("config.toml").open("rb") as f:
        return {k: str(v) for k, v in tomllib.load(f).items()}

if __name__ == "__main__":
    cfg = load()
    assert int(cfg["LISTEN_PORT"]) == 8080
    assert cfg["APP_MODE"] == "local"
    assert cfg["API_TOKEN"]
    print("configuration accepted")
