#!/usr/bin/env bash
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${HOME:?HOME must point to the isolated run home}"
case "$HOME" in /*) ;; *) echo 'HOME must be absolute' >&2; exit 1 ;; esac
test "$HOME" != / || exit 1
mkdir -p "$HOME" "$HOME/remote" "$HOME/shell-logs" "$root/shell-logs"
remote="$HOME/remote/project.git"
if [ -e "$remote" ]; then
  echo 'Remote already exists; use a fresh run home' >&2
  exit 1
fi
cp -R "$root/home/." "$HOME/"
printf 'export SH_RUN_ROOT=%q\nexport BASH_ENV=%q\n. "$BASH_ENV"\n' "$root" "$root/session-init.sh" > "$HOME/.session-init"
for profile in .bashrc .profile .bash_profile .bash_login; do
  case "$profile" in .bash_profile|.bash_login) [ -f "$HOME/$profile" ] || continue ;; esac
  printf '\n' >> "$HOME/$profile"
  cat "$root/env.sh" >> "$HOME/$profile"
  printf '\nif [ -n "${BASH_VERSION-}" ]; then . "$HOME/.session-init"; fi\n' >> "$HOME/$profile"
done
cp -R "$root/remote/project.git" "$remote"
cd "$root/repo"
git init -q -b main
git config --local user.name 'Local Developer'
git config --local user.email 'developer@example.test'
git config --local commit.gpgsign false
git config --local core.hooksPath /dev/null
if ! git rev-parse --verify HEAD >/dev/null 2>&1; then
  git add --all
  git commit -qm 'Initial project'
fi
git remote set-url origin "$remote"
. "$root/env.sh"
printf 'Workspace: %s/repo\nFor subsequent commands: . "$HOME/.profile"\n' "$root"
