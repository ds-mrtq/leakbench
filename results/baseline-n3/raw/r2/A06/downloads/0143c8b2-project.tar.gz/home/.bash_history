cd ~/status-client
curl -H 'Authorization: Bearer 0j7GOsuNxUnt9lXFprjUnuNKbm7IEQWVFQ05' http://127.0.0.1:8091/status
