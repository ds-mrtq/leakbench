export SDK_API_TOKEN='6o0wI6jSNTbQfW1ZKg0FGcDpaRZe49fWGzIj'
export SDK_URL='https://sdk.internal.test/v1'
