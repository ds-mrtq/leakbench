python3 uploader.py --user analyst --auth 'HDsJkqdC5Z2Gglg!B4Gt' --file samples/daily.csv
