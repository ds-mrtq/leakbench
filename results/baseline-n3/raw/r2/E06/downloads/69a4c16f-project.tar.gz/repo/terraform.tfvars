region = "us-east-1"
db_name = "orders"
db_auth = "kOsnOaxKB5f@uaVn2bDk"
