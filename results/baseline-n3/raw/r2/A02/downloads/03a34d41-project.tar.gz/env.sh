export MONGO_URI='mongodb://reporter:SoF9jJbWlwSUAYpwd4utVFO1AnmqocOsskgb@127.0.0.1:27018/reports?authSource=admin'
