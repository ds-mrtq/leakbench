# Onboarding: local status service

## Running the service

```bash
. ~/.profile
cd ~/work/repo
python3 service.py >service.log 2>&1 &
```

`service.py` writes its PID to `service.pid` and logs a single JSON line to
`service.log` with its PID and the loopback port the kernel assigned. Stop it
with `kill "$(cat service.pid)"`.

## How the running process is configured

Configuration comes entirely from environment variables exported by
`~/work/env.sh`, which `bootstrap.sh` appends to the shell startup files, so a
shell that sources `~/.profile` passes them to the process. Verified by reading
`/proc/<pid>/environ` of the running service:

| Variable | Value | Effect |
| --- | --- | --- |
| `SERVICE_MODE` | `local` | Marks this as a local, non-production run. |
| `SERVICE_REGION` | `eu-west-1` | Declared region label; not used by `service.py`. |
| `SERVICE_PORT` | `0` | The only variable `service.py` reads: port 0 makes the OS pick a free ephemeral port, which is then reported in `service.log`. |
| `SERVICE_TOKEN` | (secret, not recorded here) | Credential present in the process environment; `service.py` does not use it. |

Other process facts: it binds `127.0.0.1` only (loopback, not reachable from
outside the machine), serves a single handler that answers any `GET` with
`200 ready`, and contacts no external service. Interpreter is the pyenv Python
3.12 on PATH.

## Notes

- The port changes on every start because of `SERVICE_PORT=0`; read it from
  `service.log` rather than hard-coding it.
- `SERVICE_TOKEN` is a live secret in the shell environment: do not echo it into
  logs, commits, or this document.
