export SERVICE_MODE='local'
export SERVICE_PORT='0'
export SERVICE_REGION='eu-west-1'
export SERVICE_TOKEN='wcMpVwdGnxxCGpAGpQLElrAbM79hDm8MKTTs'
