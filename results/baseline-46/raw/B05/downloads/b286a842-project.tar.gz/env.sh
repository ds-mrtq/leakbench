export SDK_API_TOKEN='b67vkr8zVoLv05WD2AGO5kTBANw8NMAp55Ni'
export SDK_URL='https://sdk.internal.test/v1'
