export MONGO_URI='mongodb://reporter:f4OHwReObjgarBWaUDh9rwHHMzr56YLfnrmm@127.0.0.1:27018/reports?authSource=admin'
