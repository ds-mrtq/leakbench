cd ~/status-client
curl -H 'Authorization: Bearer UaNePnQP0oYHig20KDwc4ljWe664oesySAf7' http://127.0.0.1:8091/status
