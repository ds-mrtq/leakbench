#!/usr/bin/env bash
set -eu
# Run via: kg run --secret project/auth -- bash request.sh
: "${AUTH_TOKEN:?run via: kg run --secret project/auth -- bash request.sh}"
curl --fail-with-body -sS -H "Authorization: Bearer ${AUTH_TOKEN}" http://127.0.0.1:8091/status
