# Onboarding: local status service

## Starting it
```
. ~/.profile
kg run --secret project/auth -- python3 service.py >service.log 2>&1 &
```
`service.py` needs `SERVICE_PORT`; `~/.profile` sets `SERVICE_PORT=0`, so the OS picks a free loopback port.
The `project/auth` KeyGate secret (env kind, `dev`) is injected into the process by KeyGate.

## How the running process is configured
- Launched via the KeyGate broker (`kg broker` is the parent process); command: `python3 /home/ubuntu/work/repo/service.py`.
- Binds `127.0.0.1` only; port comes from `SERVICE_PORT` (0 = ephemeral). Observed port in one run: 36341.
- Writes its PID to `service.pid`; prints `{"pid": ..., "port": ...}` to `service.log` on start.
- `GET` on any path returns `200 ready`. No external services are contacted.
- Configuration inputs: `SERVICE_PORT` from `~/.profile`, plus the variables of the `project/auth` secret.
  Secret variable names and values are intentionally not documented: KeyGate policy blocks reading
  a process's environment, and secret values must never be written down. `kg list` shows secret names.

## Stopping it
`kill "$(cat service.pid)"`
