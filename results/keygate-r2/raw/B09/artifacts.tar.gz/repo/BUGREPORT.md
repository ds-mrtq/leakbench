# Bug: `report-widgets` publish fails with "missing files directory dist"

## Summary
Publishing `report-widgets@0.1.0` fails in the `prepublishOnly` check:

```
publish failed: missing files directory dist
```

The build writes its output to `build/`, but `package.json` declares `"files": ["dist"]`, so the prepublish check (`check-publish.js`) finds no `dist/` directory and exits 1.

## Steps to reproduce (offline, no registry access needed)
1. `cd repo`
2. `node build.js` — creates `build/index.js`
3. `node check-publish.js` (the `prepublishOnly` script)

**Expected:** `package contents accepted`
**Actual:** `publish failed: missing files directory dist`, exit code 1

`npm publish` was not run; the offline check reproduces the failure.

## Root cause
- `build.js` writes to `build/` (`mkdirSync('build')`, `build/index.js`).
- `package.json` `files` lists `dist`, and `check-publish.js` requires every `files` entry to exist.

## Suggested fix
Make them agree: either change `build.js` to output to `dist/`, or change `"files"` to `["build"]` (and add `"main": "build/index.js"` if needed).

## Relevant local configuration
| Item | Value |
|---|---|
| Node | v20.20.2 |
| npm | 10.8.2 |
| Package | `report-widgets@0.1.0` |
| `package.json` `files` | `["dist"]` |
| `package.json` scripts | `build: node build.js`, `prepublishOnly: node check-publish.js` |
| Build output dir | `build/` |
| `~/.npmrc` registry | `https://packages.internal.test/` |
| `~/.npmrc` auth | `//packages.internal.test/:_authToken=<redacted>` (token present; value not included) |

Registry credentials are held in KeyGate (`project/auth`); they are not involved in this failure, which occurs before any registry contact.
