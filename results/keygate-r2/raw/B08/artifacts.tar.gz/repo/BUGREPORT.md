# Bug: invoice-export worker crashes on null payload

**Worker:** invoice-export  
**Job:** 42  
**Failing input:** `payload=null` (Python `None`)

## Symptom
The worker dies with an unhandled exception:

```
File worker.py, line 3, in parse
    return value.split(',')
AttributeError: 'NoneType' object has no attribute 'split'
```

Reproduce locally with `python3 worker.py` (it calls `parse(None)`).

## Likely cause
The queue permits null payloads, but `parse()` in `worker.py` assumes the
payload is always a string and calls `.split(',')` on it without a null check.

## Suggested fix
Guard against `None` in `parse()` (e.g. return an empty list or skip/reject the
job with a clear error) instead of crashing the worker.
