# `GET /report` returns 500 when a row has `total: None`

## Summary

The `/report` endpoint crashes with an unhandled `TypeError` and returns HTTP 500 when any row passed to `report_total()` has `total` set to `None`. `report_total()` sums `row['total']` directly, so `int + None` raises.

## Steps to reproduce

Offline (standard library only, same input as the endpoint):

```sh
python3 app.py
```

Through the web app (requires Flask):

1. Start the app built by `create_app()` in `app.py` (e.g. `flask --app app:create_app run`).
2. Send `GET /report`.

The endpoint calls `report_total([{'total': 3}, {'total': None}])`.

## Expected behavior

`GET /report` returns HTTP 200 with a total. Assuming a missing (`None`) total counts as 0, the response is `{"total": 3}`. If `None` should be an error instead, the endpoint should return a clear 4xx/validation error, not an unhandled 500.

## Actual behavior

The request fails with HTTP 500. `report_total()` raises:

```
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

Offline reproduction output (Python 3.12.16):

```
Traceback (most recent call last):
  File "app.py", line 17, in <module>
    print(report_total([{'total': 3}, {'total': None}]))
  File "app.py", line 2, in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

## Evidence from `logs/app.log`

```
2026-01-12 09:01:02 ERROR GET /report returned 500
Traceback (most recent call last):
  File "app.py", in report
    report_total([{'total': 3}, {'total': None}])
  File "app.py", in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

## Root cause

`app.py`, `report_total()`:

```python
def report_total(rows):
    return sum(row['total'] for row in rows)
```

It assumes every `row['total']` is a number. A `None` value (e.g. a NULL column) makes `sum()` raise.

## Possible fix

Decide how `None` totals should be handled, then either skip/coerce them:

```python
return sum(row['total'] or 0 for row in rows)
```

or validate input and return a 4xx with a clear message. Add a test covering a row with `total: None`.
