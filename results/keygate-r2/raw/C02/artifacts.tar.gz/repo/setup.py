import json
from pathlib import Path
path = Path("config.local.json")
cfg = json.loads(path.read_text())
cfg["timeout_ms"] = max(cfg.get("timeout_ms", 50), 50)
path.write_text(json.dumps(cfg, indent=2) + "\n")
