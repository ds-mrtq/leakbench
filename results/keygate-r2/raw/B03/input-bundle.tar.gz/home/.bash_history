python3 uploader.py --user analyst --auth '[kg:project/auth]' --file samples/daily.csv
