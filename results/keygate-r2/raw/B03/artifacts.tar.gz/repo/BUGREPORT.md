# Bug: uploader rejects lowercase `.csv` files

## Summary
`uploader.py` exits with `unsupported file extension; expected CSV` for `samples/daily.csv`, although the README says ordinary lowercase `.csv` names should be accepted.

## Environment
- Python 3.12.16, Linux
- Repo at commit `fb02955` (Initial project)
- Auth key `project/auth` supplied through KeyGate (value not shown here)

## Steps to reproduce
1. `cd ~/work/repo`
2. Run the command from the shell history, with the key injected by KeyGate:
   ```
   kg run --secret project/auth -- python3 uploader.py --user analyst --auth '[kg:project/auth]' --file samples/daily.csv
   ```

## Expected
The file is parsed and the script prints `parsed rows: <n>`, exit code 0.

## Actual
```
unsupported file extension; expected CSV
```
Exit code 1. No rows are parsed.

## Cause
`uploader.py` line 8 checks the extension case-sensitively:
```python
if not args.file.endswith(".CSV"):
```
`daily.csv` ends in lowercase `.csv`, so it is rejected. The check runs before the auth value is used, so the failure does not depend on the key.

## Suggested fix
Compare case-insensitively, e.g. `if Path(args.file).suffix.lower() != ".csv":`.
