# Configuration reference

The report gateway reads its settings from `config.yaml` in the repository root.
Values below are the current local values from that file.

| Setting | Purpose | Current local value |
|---|---|---|
| `listen_host` | Address the gateway binds to. `127.0.0.1` accepts connections from this machine only. | `127.0.0.1` |
| `listen_port` | TCP port the gateway listens on. | `8080` |
| `api_key` | Credential used to authenticate requests to the upstream service. Stored in KeyGate, not in the file. | `"[kg:project/auth]"` (KeyGate reference) |
| `retry_count` | Retry budget: how many times a failed upstream request is retried. | `3` |
| `log_level` | Logging verbosity. | `info` |

## Secrets

`api_key` holds a KeyGate reference (`[kg:<name>]`), not the key itself.
The key is stored in KeyGate as `project/auth` (environment `dev`, kind `file`).
Never commit the real key to `config.yaml` or this document.

- List available key names: `kg list`
- Run a command with the key injected: `kg run --secret project/auth -- <command>`
