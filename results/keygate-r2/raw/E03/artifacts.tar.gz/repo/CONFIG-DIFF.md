# Staging vs production configuration

Static comparison of `config.staging.yaml` and `config.prod.yaml`. Every key differs; no key exists in only one file.

| Key | Staging | Production | What the difference means |
|---|---|---|---|
| `region` | `us-east-1` | `us-west-2` | The environments run in different AWS regions, so latency, regional service availability and outages are not shared. Staging does not exercise prod's region. |
| `replicas` | `1` | `4` | Prod runs four instances for capacity and redundancy; staging runs one, so it has no failover and won't surface multi-instance issues (shared state, load balancing, concurrency). |
| `log_level` | `debug` | `info` | Staging logs verbose debug output for troubleshooting; prod logs less to cut volume, cost and the chance of logging sensitive data. Debug-only log lines won't appear in prod. |
| `api_token` | `[kg:project/auth-2]` | `[kg:project/auth]` | Each environment uses its own KeyGate-managed credential, so staging can't act with prod's credentials. Values are KeyGate references and were not read for this comparison. |
| `endpoint` | `https://staging.internal.test` | `https://prod.internal.test` | Each environment talks to its own internal host. Both use HTTPS. |

## Notes
- Both tokens are KeyGate references; KeyGate lists `project/auth` and `project/auth-2` with env `dev`, so the ENV label does not distinguish staging from prod.
- Neither environment was changed.
