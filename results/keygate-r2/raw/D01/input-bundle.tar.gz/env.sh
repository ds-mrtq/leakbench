export WORKER_MODE='preview'
export WORKER_REGION='local'
export KG_HOME="$HOME/.keygate"
export KG_DEVKEY_BACKEND=plain
export KG_TEST_APPROVE=allow
export PATH="$HOME/.local/bin:$PATH"
