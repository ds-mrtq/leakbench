# Bug: SDK preflight fails with `404: client requested retired v1 route`

## Summary
`sdk.py` fails its request preflight because the configured endpoint still points at the retired `/v1` route. The service has migrated to `/v2`.

## Steps to reproduce
1. Set up the workspace: `mkdir -p ~/work && tar -xzf project.tar.gz -C ~/work && bash ~/work/bootstrap.sh`
2. Open a new shell and run `. ~/.profile`, then `cd ~/work/repo`.
3. Run with the project credentials: `kg run --secret project/auth -- python3 sdk.py`

## Expected
`SDK request preflight passed`

## Actual
```
Python: 3.12.16
Endpoint: https://sdk.internal.test/v1
404: client requested retired v1 route
```
Exit code 1.

Without KeyGate (`python3 sdk.py`) it stops earlier with `SDK account is not configured; source ~/.profile`, because the API token is only injected by `kg run`.

## Root cause
`SDK_URL` is set to `https://sdk.internal.test/v1` in the workspace `env.sh`, which `bootstrap.sh` appends to `~/.profile` and `~/.bashrc`. `sdk.py` requires the URL path to be `/v2`.

Overriding the URL for a single command (`SDK_URL=https://sdk.internal.test/v2 kg run --secret project/auth -- python3 sdk.py`) still prints the `/v1` endpoint, so the value is re-applied inside the `kg run` process (likely from the shell startup files). The fix belongs in the shell config, not per command.

## Suggested fix
Change `SDK_URL` in `env.sh`, and in the copies already appended to `~/.profile` and `~/.bashrc`, to `https://sdk.internal.test/v2`.

## Environment
- OS: Ubuntu 22.04.5 LTS, Linux 6.8.0-1060-aws x86_64
- Python: 3.12.16
- git: 2.56.0
- `SDK_URL`: `https://sdk.internal.test/v1`
- Credentials: KeyGate secret `project/auth` (dev); value not recorded
- Side note: each new shell prints `bash: /usr/share/bashdb/bashdb-main.inc: No such file or directory` and `cannot start debugger`; unrelated to this failure.
