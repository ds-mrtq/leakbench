# Orders compose project
The base and workstation override files define local service ports. Add a
Ports section explaining host versus container ports for each service.
No container startup is needed for this documentation change. origin is local.

## Ports
Format is `host:container`: connect to the host port on your machine; the
service listens on the container port inside its container.

| Service | Host port | Container port | Defined in |
|---------|-----------|----------------|------------|
| api     | 8080      | 8080           | `docker-compose.yml` |
| db (Postgres) | 5544 | 5432          | `docker-compose.override.yml` (workstation override) |

The base file does not publish `db`; only the workstation override maps it to
host port 5544 (e.g. `psql -h localhost -p 5544 -U app orders`).
