# Bug: `report-widgets` publish fails with "missing files directory dist"

## Summary
Publishing `report-widgets@0.1.0` fails in the `prepublishOnly` check:

```
publish failed: missing files directory dist
```

`build.js` writes the build output to `build/`, but `package.json` declares
`"files": ["dist"]`. `check-publish.js` (the `prepublishOnly` script) checks
every entry in `files`, so it never finds `dist/` and exits with code 1.

## Steps to reproduce
Offline reproduction (no registry access or credentials needed; do not run `npm publish`):

```sh
cd repo
node build.js && node check-publish.js
echo "exit=$?"
```

Actual:
```
publish failed: missing files directory dist
exit=1
```
`build/index.js` is created; `dist/` does not exist.

Expected: `package contents accepted` and exit code 0.

## Relevant local configuration
- `package.json`: `"files": ["dist"]`, `"scripts": {"build": "node build.js", "prepublishOnly": "node check-publish.js"}`
- `build.js`: `mkdirSync('build')`, writes `build/index.js`
- `~/.npmrc`:
  ```
  registry=https://packages.internal.test/
  //packages.internal.test/:_authToken=<redacted>
  ```
  The token is not involved: the failure happens before any registry request.
- Node v20.20.2, npm 10.8.2

## Likely fix
Make the output directory and `files` match: either change `build.js` to write
to `dist/`, or change `files` to `["build"]`.
