# Orders infrastructure

## What it deploys

`main.tf` uses the AWS provider to create one resource, `aws_db_instance.orders`:
a single PostgreSQL RDS instance.

| Setting | Value |
|---|---|
| Engine | `postgres` (no version pinned, so AWS picks the current default) |
| Instance class | `db.t3.micro` |
| Storage | 20 GiB (default storage type, no autoscaling) |
| Database name | `var.db_name` (`orders` in `terraform.tfvars`) |
| Master user | `app` |
| Master credential | taken from `var.db_auth` |
| Public access | disabled (`publicly_accessible` is false) |
| Final snapshot on destroy | skipped (`skip_final_snapshot` is true) |

No VPC, subnet group, security group, parameter group or backup settings are
defined, so the instance lands in the account's default VPC with its default
security group and AWS defaults for everything else.

## Inputs

| Variable | Type | Sensitive | Value in `terraform.tfvars` | Purpose |
|---|---|---|---|---|
| `region` | string | no | `us-east-1` | AWS region for the provider |
| `db_name` | string | no | `orders` | Initial database created on the instance |
| `db_auth` | string | yes | `[kg:project/auth]` (KeyGate placeholder) | Master credential for user `app` |

`db_auth` is not stored in the repo: the tfvars value is a KeyGate reference
resolved at run time (for example `kg run --secret <name> -- terraform plan`).
Never replace the placeholder with the real value in a committed file.

## Operational risks

1. **Data loss on destroy.** With `skip_final_snapshot` true, `terraform destroy`
   or any change that forces replacement deletes the database with no snapshot.
   Neither `deletion_protection` nor `lifecycle { prevent_destroy }` is set.
2. **No backup policy.** `backup_retention_period` is not set; the provider
   default applies, and point-in-time recovery is not guaranteed by this config.
3. **Unpinned engine version.** Without `engine_version`, the version depends on
   when the instance is created, and later plans may show drift or upgrades.
4. **Single AZ, smallest burstable class.** No `multi_az`; `db.t3.micro` can run
   out of CPU credits. An AZ outage or credit exhaustion means downtime.
5. **Implicit network placement.** Default VPC and default security group, with
   no explicit ingress rules or subnet group, so reachability depends on account
   defaults rather than code.
6. **Encryption not explicit.** `storage_encrypted` is not set and cannot be
   turned on later without replacing the instance.
7. **Credential in state.** `sensitive` only hides `db_auth` from CLI output;
   Terraform state still stores it in plain text. No backend is configured, so
   state is local by default: use an encrypted, access-restricted remote
   backend, or let AWS Secrets Manager manage the master credential
   (the `manage_master_user_password` argument).
8. **No version constraints.** There is no `required_providers` or
   `required_version` block, so provider upgrades can change behaviour.
9. **Storage fixed at 20 GiB.** No `max_allocated_storage`; a full disk stops
   writes.
