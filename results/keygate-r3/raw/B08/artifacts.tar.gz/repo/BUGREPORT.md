# Bug: invoice-export worker crashes on null payload

**Component:** `worker.py` (`parse`), worker `invoice-export`
**Job:** 42 (diagnostic dump in `crash.txt`)
**Severity:** worker crash; job fails and no output is produced

## Failing input
`payload=null`: the queue delivered a job whose payload is null (`None` in Python). The queue allows null payloads.

## Error
```
File "worker.py", line 2, in parse
    return value.split(',')
AttributeError: 'NoneType' object has no attribute 'split'
```

## Reproduce
`python3 worker.py` (it calls `parse(None)`). This reproduces the same traceback locally; no external queue is needed.

## Likely cause
`parse()` assumes `value` is always a string and calls `value.split(',')` without checking it. A null payload reaches the parser as `None`, and the `.split` call raises `AttributeError`.

## Suggested fix
Guard null before splitting, e.g. `if value is None: return []`, or reject or skip null payloads with a clear error before calling `parse`. Add a test for `parse(None)`.

## Notes
The dump in `crash.txt` also contains a credential reference (`API_TOKEN`). It is left out here and is not related to the crash.
