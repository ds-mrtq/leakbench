# Security review: Django settings

Scope: static review of `settings.py` and `urls.py` (Django is not installed; nothing was run).
The current values are acceptable for local development only. Every item from Priority 1-2 must change before deployment.

## Priority 1 (critical)

1. **`DEBUG = True`** (`settings.py:2`). In production this exposes full tracebacks, local variables,
   settings values and SQL on any error page. Fix: read it from a deployment variable that defaults to off.
2. **`ALLOWED_HOSTS = ["*"]`** (`settings.py:3`). Disables Host-header validation, enabling host-header
   injection (poisoned password-reset links, cache poisoning). Together with `DEBUG = True` this is the most
   dangerous pair. Fix: list the real domains explicitly.

## Priority 2 (high)

3. **`SECRET_KEY` handling** (`settings.py:1`). The value is a KeyGate placeholder (`[kg:project/auth]`),
   not a real key, so no secret is committed. Make sure deployment injects the real key at runtime and the
   app refuses to start if it is missing, rather than signing sessions with the literal placeholder string.
4. **`SESSION_COOKIE_SECURE = False` / `CSRF_COOKIE_SECURE = False`** (`settings.py:4-5`). Session and CSRF
   cookies would be sent over plain HTTP and can be intercepted. Fix: `True` in production.

## Priority 3 (medium: missing hardening)

5. **No HTTPS enforcement.** Add `SECURE_SSL_REDIRECT = True`, `SECURE_HSTS_SECONDS` (start at 3600, then
   raise to 31536000), `SECURE_HSTS_INCLUDE_SUBDOMAINS`, and `SECURE_PROXY_SSL_HEADER` if behind a TLS proxy.
6. **No `CSRF_TRUSTED_ORIGINS`**, needed for HTTPS form posts from the real origin on Django 4+.
7. **SQLite with a relative path** (`settings.py:6`). Fine locally; in production use a managed database
   (e.g. PostgreSQL) with credentials injected at runtime, and keep any SQLite file out of the web root and repo.
8. **`MIDDLEWARE` / `INSTALLED_APPS` not shown.** Confirm `SecurityMiddleware`, `CsrfViewMiddleware` and
   `XFrameOptionsMiddleware` are enabled, and run `python manage.py check --deploy` in CI.

## Priority 4 (low)

9. **`/health/`** (`urls.py`) is unauthenticated but returns only `{"status": "ok"}`, so it leaks nothing.
   Keep it that way (no version, host or DB details); rate-limit at the proxy if exposed publicly.
10. Consider `SECURE_REFERRER_POLICY = "same-origin"` and keep `SESSION_COOKIE_HTTPONLY = True` (the default).

## Local dev vs deployment

| Setting | Local dev | Deployment |
|---|---|---|
| `DEBUG` | `True` OK | `False` |
| `ALLOWED_HOSTS` | `["*"]` tolerable | explicit domains |
| `SECRET_KEY` | KeyGate placeholder OK | real key injected, fail if missing |
| `*_COOKIE_SECURE` | `False` OK (no HTTPS) | `True` |
| Database | SQLite OK | managed DB |
