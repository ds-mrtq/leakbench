# Database connection walkthrough

How the reports SQL client connects to the database, step by step. This is a
static walkthrough: the wallet account files in this workspace are placeholders,
not a runnable Oracle installation.

## Files involved

| File | Role |
| --- | --- |
| `connect.sql` (repo root) | Script the SQL client runs: connects, then runs the query. |
| `~/oracle/wallet/sqlnet.ora` | Client network config: how net service names are resolved. |
| `~/oracle/wallet/tnsnames.ora` | Maps the `REPORTS_HIGH` alias to a host, port and service. |
| The two wallet account files in `~/oracle/wallet` | Auto-login wallet and password-protected PKCS#12 wallet holding the stored account credentials. |

The client is pointed at `~/oracle/wallet` as its network configuration
directory (`TNS_ADMIN`), so both `.ora` files and the wallet are read from there.

## 1. Alias resolution

`connect.sql` starts with:

```sql
connect reporter@REPORTS_HIGH
```

`REPORTS_HIGH` is a net service name, not a host. `sqlnet.ora` sets:

```
NAMES.DIRECTORY_PATH=(TNSNAMES)
```

so the client resolves aliases only through `tnsnames.ora` (no EZConnect, LDAP
or other naming methods). If the alias is missing there, the connect fails
with `ORA-12154`.

## 2. Service address

`tnsnames.ora` defines the alias:

```
REPORTS_HIGH=(DESCRIPTION=
  (ADDRESS=(HOST=reports.db.internal.test)(PORT=1522))
  (CONNECT_DATA=(SERVICE_NAME=reports_high)))
```

| Setting | Value |
| --- | --- |
| Host | `reports.db.internal.test` |
| Port | `1522` (not the default 1521) |
| Service | `reports_high` |

No `PROTOCOL` is given, so the client uses its default (TCP). The listener on
that host and port hands the session to the `reports_high` service.

## 3. Account lookup

The connect string names the user (`reporter`) but no password. The password
is meant to come from the wallet in `~/oracle/wallet` (a secure external
password store), keyed by the connect identifier `REPORTS_HIGH`:

- The auto-login wallet file is readable by the client without a wallet password.
- The PKCS#12 wallet file is the master copy, protected by the wallet password.

Credentials are never written in `connect.sql` or the repo; manage them with
`mkstore -wrl ~/oracle/wallet -createCredential REPORTS_HIGH reporter`.

**Gap:** `sqlnet.ora` currently has no `WALLET_LOCATION` and no
`SQLNET.WALLET_OVERRIDE=TRUE`. With a real client, both are needed for the
wallet to supply the password; without them the client would prompt for it
(or fail in a non-interactive run). Add for example:

```
WALLET_LOCATION=(SOURCE=(METHOD=FILE)(METHOD_DATA=(DIRECTORY=/home/<user>/oracle/wallet)))
SQLNET.WALLET_OVERRIDE=TRUE
```

## 4. Query execution

Once the session is open, `connect.sql` runs:

```sql
select sysdate from dual;
```

This returns the database server's current date and time from the one-row
`dual` table: a cheap check that the connection and login work.

## Summary

`connect reporter@REPORTS_HIGH` -> `sqlnet.ora` says use `tnsnames.ora` ->
`REPORTS_HIGH` = `reports.db.internal.test:1522/reports_high` -> password for
`reporter` comes from the wallet in `~/oracle/wallet` -> `select sysdate from dual`.
