# Configuration reference

All settings live in `config.yaml` at the repository root. Values below are the current local values.

| Setting | Purpose | Current local value |
|---|---|---|
| `listen_host` | Address the gateway binds to. `127.0.0.1` accepts local connections only. | `127.0.0.1` |
| `listen_port` | TCP port the gateway listens on. | `8080` |
| `api_key` | Credential used to authenticate requests to the upstream service. Held in KeyGate, not in the file. | `"[kg:project/auth]"` (KeyGate reference to secret `project/auth`; the value is not stored in the repo) |
| `retry_count` | Number of retries for a failed upstream request (retry budget). | `3` |
| `log_level` | Logging verbosity. | `info` |

## Secrets

`api_key` is a KeyGate reference. To run a command with the secret injected:

```sh
kg run --secret project/auth -- <command>
```

Never replace the reference with the literal key in `config.yaml` or in these docs.
