# Orders compose project
The base and workstation override files define local service ports. Add a
Ports section explaining host versus container ports for each service.
No container startup is needed for this documentation change. origin is local.

## Ports

Compose port mappings use `HOST:CONTAINER`: the host port is what you connect
to from your machine (`localhost:<host>`); the container port is what the
service listens on inside the Compose network (other services reach it as
`<service>:<container>`).

| Service | Host port | Container port | Defined in |
|---------|-----------|----------------|------------|
| `api` (python:3-alpine) | 8080 | 8080 | `docker-compose.yml` |
| `db` (postgres:16) | 5544 | 5432 | `docker-compose.override.yml` |

The `db` host port comes from the workstation override; without it Postgres is
only reachable inside the Compose network on `db:5432`.
