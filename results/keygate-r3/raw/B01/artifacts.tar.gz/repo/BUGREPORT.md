# `GET /report` returns 500 when a row has `total: None`

## Summary
The `/report` endpoint crashes with an unhandled `TypeError` when any input row has `total` set to `None`. `report_total()` in `app.py` passes every `row['total']` straight to `sum()`, and `int + None` raises.

## Steps to reproduce
Offline, standard library only:
1. `cd repo`
2. `python3 app.py`

Through the web app (needs Flask):
1. `pip install flask`
2. `flask --app app:create_app run`
3. `curl -i http://127.0.0.1:5000/report`

Both paths call `report_total([{'total': 3}, {'total': None}])`.

## Expected behavior
`/report` returns 200 with a total. Most likely `{"total": 3}`, with `None` counted as missing (or 0). If `None` totals are invalid data, the endpoint should return a clear 4xx/validation error, not a 500.

## Actual behavior
The request fails with HTTP 500. The offline repro raises the same exception:

```
Traceback (most recent call last):
  File "app.py", line 17, in <module>
    print(report_total([{'total': 3}, {'total': None}]))
  File "app.py", line 2, in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

## Evidence from `logs/app.log`
```
2026-01-12 09:01:02 ERROR GET /report returned 500
Traceback (most recent call last):
  File "app.py", in report
    report_total([{'total': 3}, {'total': None}])
  File "app.py", in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```
(The log's database connection line is left out on purpose: it is not related to the crash.)

## Environment
- Python 3.12
- `app.py` from the initial commit (`e8a9afd`)

## Possible fix
Skip or coalesce `None` values in `report_total`, for example `sum(row['total'] or 0 for row in rows)`, and add a test with a `None` total.
