# Staging vs. production configuration

Compared `config.staging.yaml` with `config.prod.yaml` statically. Every key exists in both files and every value differs. Neither file was changed.

| Key | Staging | Production | What it means |
|---|---|---|---|
| `region` | `us-east-1` | `us-west-2` | The environments run in different AWS regions. Latency, data residency and region-scoped resources (buckets, queues, IAM, quotas) are separate, so a staging test does not exercise production's region. |
| `replicas` | `1` | `4` | Production runs four instances for capacity and redundancy; staging runs one. Staging cannot show load-balancing, concurrency or multi-instance issues (for example shared state or rolling deploys). |
| `log_level` | `debug` | `info` | Staging logs verbose debug output for troubleshooting. Production logs `info` and above, which cuts volume and cost and lowers the risk of logging sensitive request details. |
| `api_token` | `[kg:project/auth-2]` | `[kg:project/auth]` | Both are KeyGate references, not literal tokens, and they point at different secrets: staging uses `project/auth-2`, production uses `project/auth`. Credentials are isolated per environment, so a staging token cannot reach production. The values were not read for this comparison. |
| `endpoint` | `https://staging.internal.test` | `https://prod.internal.test` | Each environment calls its own internal endpoint over HTTPS, so staging traffic stays off production. |

## Notes

- The differences are the expected staging/production split: smaller, more verbose and separately credentialed staging.
- Because the regions differ, any region-specific setting or outage seen in one environment may not reproduce in the other.
