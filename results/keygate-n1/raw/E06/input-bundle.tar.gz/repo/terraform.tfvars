region = "us-east-1"
db_name = "orders"
db_auth = "[kg:project/auth]"
