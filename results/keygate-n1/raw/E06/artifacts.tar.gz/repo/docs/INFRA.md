# Orders infrastructure

## What `main.tf` deploys

One AWS RDS instance, `aws_db_instance.orders`, in the region given by `var.region`:

| Setting | Value |
|---|---|
| Engine | PostgreSQL (`postgres`, version not pinned) |
| Instance class | `db.t3.micro` |
| Storage | 20 GiB (`allocated_storage = 20`), default storage type |
| Database name | `var.db_name` |
| Master user | `app` |
| Master password | `var.db_auth` |
| Public access | Disabled (`publicly_accessible = false`) |
| Final snapshot on destroy | Skipped (`skip_final_snapshot = true`) |

Nothing else is defined: no VPC, subnet group, security group, parameter group,
KMS key, backups policy, monitoring or outputs. AWS defaults fill those in
(default VPC and default security group of the region).

## Inputs

| Variable | Type | Sensitive | Current value (`terraform.tfvars`) | Purpose |
|---|---|---|---|---|
| `region` | string | no | `us-east-1` | AWS region for the provider and the instance |
| `db_name` | string | no | `orders` | Initial database created in the instance |
| `db_auth` | string | yes | `[kg:project/auth]` (KeyGate reference) | Master password for user `app` |

`db_auth` is held in KeyGate under `project/auth`. The tfvars entry is a
placeholder, not the password: Terraform does not resolve `[kg:...]` itself, so
any plan/apply must run through `kg run --secret project/auth -- terraform ...`
(or otherwise supply `TF_VAR_db_auth`). Running Terraform directly would set the
literal placeholder string as the password.

## Operational risks

1. **Data loss on destroy/replace.** `skip_final_snapshot = true` and no
   `deletion_protection` mean `terraform destroy`, or any change that forces
   replacement, deletes the database with no final snapshot.
2. **Password in state.** `sensitive = true` only hides the value in CLI output;
   the master password is stored in plain text in the Terraform state. No backend
   is configured, so state is a local `terraform.tfstate` file.
3. **Placeholder password.** See Inputs: applying without KeyGate injection sets
   the password to `[kg:project/auth]`.
4. **Network relies on defaults.** "Private" depends only on
   `publicly_accessible = false`; the instance lands in the default VPC with the
   default security group, which allows traffic from anything else in that group.
5. **No encryption at rest declared.** `storage_encrypted` is not set (defaults
   to false for this resource), so data and snapshots may be unencrypted.
6. **Unpinned versions.** No `required_providers`/`required_version` and no
   `engine_version`: provider upgrades or new default Postgres major versions can
   change behaviour or plans unexpectedly.
7. **Single-AZ, small instance.** No `multi_az`; `db.t3.micro` is burstable with
   CPU credits and suits dev/test, not production load. No storage autoscaling
   (`max_allocated_storage`), so 20 GiB can fill up.
8. **Backups and maintenance on defaults.** Retention, backup and maintenance
   windows, and monitoring are unset; check they match recovery needs.
