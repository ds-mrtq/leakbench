export SERVICE_MODE='local'
export SERVICE_PORT='0'
export SERVICE_REGION='eu-west-1'
export KG_HOME="$HOME/.keygate"
export KG_DEVKEY_BACKEND=plain
export KG_TEST_APPROVE=allow
export PATH="$HOME/.local/bin:$PATH"
