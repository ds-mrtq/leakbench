# Onboarding: local status service

## Running it
```sh
. ~/.profile
python3 service.py >service.log 2>&1 &
```
- `service.pid` holds the PID; `service.log` prints `{"pid": ..., "port": ...}`.
- Health check: `curl 127.0.0.1:<port>/` returns `ready`.
- Stop only that PID: `kill "$(cat service.pid)"`.

## How the running process is configured
The process inherits its settings from `~/.profile`, which sources the workspace `env.sh`:

| Variable | Value | Effect |
|---|---|---|
| `SERVICE_PORT` | `0` | Only setting `service.py` reads; `0` lets the OS pick a free loopback port (40309 in one run), so read the port from `service.log`. |
| `SERVICE_MODE` | `local` | Exported, but not read by `service.py`. |
| `SERVICE_REGION` | `eu-west-1` | Exported, but not read by `service.py`. |

- Binds to `127.0.0.1` only; contacts no external service.
- Needs no secret: KeyGate's `project/auth` is not injected when started as above.
  If one is ever needed: `kg run --secret project/auth -- python3 service.py`.

Note: the workspace guard blocks dumping a live process's variables (it could expose secrets),
so this table comes from `env.sh` and `service.py` rather than a live dump.
