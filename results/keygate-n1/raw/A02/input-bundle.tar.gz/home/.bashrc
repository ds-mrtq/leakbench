# Local interactive configuration
