# Security review: Django settings (`settings.py`, `urls.py`)

Static review only (Django is not installed in this bundle). Ordered by priority.
"Secret store" below means values injected at runtime (e.g. `kg run --secret ...` or the deploy platform's secret manager), never literals in the repo.

## P1 — Critical (must change before any deployment)

1. **`DEBUG = True`**
   - Risk: unhandled errors render full tracebacks, local variables, settings and SQL to any visitor; Django also keeps every query in memory.
   - Fix: default to `False` and enable it only in a local-dev settings module.

2. **`ALLOWED_HOSTS = ["*"]`**
   - Risk: accepts any `Host` header, enabling host-header injection (poisoned password-reset links, cache poisoning) and disabling Django's host validation.
   - Fix: list the real domains (e.g. `["app.example.com"]`), supplied per deployment. `["*"]` is acceptable only for local dev.

3. **`SECRET_KEY` handling**
   - Current value is a KeyGate placeholder (`[kg:project/auth]`), not a literal key, which is good: no secret is committed.
   - Risk: if the placeholder is not substituted at runtime, Django runs with a known, public string as its signing key, so sessions, password-reset tokens and signed cookies become forgeable.
   - Fix: inject the key from the secret store with no default, and refuse to start if the value still looks like `[kg:...]`. `settings.py` is currently untracked in git; keep any real key out of the repo.

## P2 — High

4. **`SESSION_COOKIE_SECURE = False` / `CSRF_COOKIE_SECURE = False`**
   - Risk: session and CSRF cookies are sent over plain HTTP and can be stolen on the network (session hijack).
   - Fix (production): set both to `True`. `False` is fine for local `runserver` over HTTP.

5. **No HTTPS enforcement / security headers configured**
   - Missing: `SECURE_SSL_REDIRECT = True`, `SECURE_HSTS_SECONDS` (start small, e.g. 3600, then 31536000) with `SECURE_HSTS_INCLUDE_SUBDOMAINS`, `SECURE_PROXY_SSL_HEADER` if behind a TLS-terminating proxy, and `CSRF_TRUSTED_ORIGINS` for the real origins.
   - The excerpt defines no `MIDDLEWARE`; confirm `SecurityMiddleware`, `CsrfViewMiddleware` and `XFrameOptionsMiddleware` are enabled.

## P3 — Medium

6. **SQLite with a relative path (`NAME: "db.sqlite3"`)**
   - Risk: the file location depends on the working directory and may land in a served or world-readable directory; SQLite is not suited to concurrent production load.
   - Fix: production uses PostgreSQL/MySQL with credentials from the secret store; for dev use `BASE_DIR / "db.sqlite3"` and add it to `.gitignore`.

7. **Unauthenticated `/health/` endpoint (`urls.py`)**
   - Low risk as written: returns only `{"status": "ok"}`. Keep it free of version, DB or host details; consider rate limiting at the proxy.

## P4 — Low / hygiene

8. Keep `SESSION_COOKIE_HTTPONLY = True` (default); add `SECURE_CONTENT_TYPE_NOSNIFF = True`, `X_FRAME_OPTIONS = "DENY"`, `SECURE_REFERRER_POLICY = "same-origin"`.
9. Split settings into dev/prod modules and run `python manage.py check --deploy` in CI against production settings.

## Dev vs. deployment summary

| Setting | Local dev | Deployment |
|---|---|---|
| `DEBUG` | `True` OK | must be `False` |
| `ALLOWED_HOSTS` | `["*"]` / `["localhost"]` OK | explicit domains |
| `SECRET_KEY` | any runtime-supplied value | strong key from secret store, no fallback |
| `SESSION_/CSRF_COOKIE_SECURE` | `False` OK | `True` |
| HTTPS redirect / HSTS | off | on |
| SQLite relative path | OK | managed DB, secret-store credentials |
