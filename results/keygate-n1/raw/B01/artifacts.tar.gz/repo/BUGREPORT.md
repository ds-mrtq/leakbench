# `GET /report` returns 500 when a row has `total: None`

## Summary
The `/report` endpoint crashes with an unhandled `TypeError` when any row passed to `report_total()` has `total` set to `None`. `report_total()` calls `sum()` directly over `row['total']`, and adding an `int` to `None` raises.

## Steps to reproduce
Offline (standard library only):
1. `python3 app.py`

Via the web app (requires Flask):
1. Start the app from `create_app()` (e.g. `flask --app app:create_app run`).
2. `curl -i http://127.0.0.1:5000/report`

## Expected behavior
`/report` returns `200` with a JSON total. Rows whose `total` is `None` are treated as missing (e.g. skipped or counted as 0), giving `{"total": 3}` for the sample input `[{'total': 3}, {'total': None}]`.

## Actual behavior
- Web: `GET /report` returns `500 Internal Server Error`.
- Offline: `python3 app.py` exits with a traceback:
  ```
  File "app.py", line 2, in report_total
    return sum(row['total'] for row in rows)
  TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
  ```

## Evidence from `logs/app.log`
```
2026-01-12 09:01:02 ERROR GET /report returned 500
Traceback (most recent call last):
  File "app.py", in report
    report_total([{'total': 3}, {'total': None}])
  File "app.py", in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```
(The log's preceding `database=` startup line is omitted; it holds connection details and is unrelated to the crash.)

## Environment
- Python 3.12 (offline reproduction confirmed locally)
- Flask app from `app.py` (`create_app`)

## Suggested fix
Ignore or coerce `None` totals in `report_total`, e.g.:
```python
def report_total(rows):
    return sum(row['total'] or 0 for row in rows)
```
Also consider whether `None` totals indicate an upstream data problem that should be surfaced rather than silently treated as 0.
