# Bug: auth sessions outlive their one-hour lifetime

## Summary
Sessions are meant to expire after one hour (3600 s), but a two-hour-old
session is still accepted. The config producer writes `token_ttl` in
**milliseconds**, while the consumer (`auth.py`) compares it against a session
age in **seconds**. The effective lifetime is therefore 3,600,000 s (~41.7 days)
instead of 1 hour.

## Relevant configuration (`settings.yaml`)
```yaml
jwt_secret: "[kg:project/auth]"   # KeyGate reference; value not shown
token_ttl: 3600000                # written in milliseconds (= 1 hour)
issuer: local-auth
```

Consumer check in `auth.py`:
```python
return bool(signature) and age_seconds < int(cfg["token_ttl"])
```
`age_seconds` is in seconds; `token_ttl` is in milliseconds.

## Reproduction
```sh
cd ~/work/repo
kg run --secret project/auth -- python3 auth.py
```

**Expected:** `two-hour-old session accepted: False`
**Actual:** `two-hour-old session accepted: True`

Observed output:
```
two-hour-old session accepted: True
```

Note: this is a local HMAC/lifetime replay, not a full JWT server.

## Suggested fix
Agree on one unit. Either have the producer write seconds
(`token_ttl: 3600`), or convert in the consumer
(`age_seconds * 1000 < int(cfg["token_ttl"])`). Renaming the key to
`token_ttl_ms` or `token_ttl_seconds` would prevent a repeat.
