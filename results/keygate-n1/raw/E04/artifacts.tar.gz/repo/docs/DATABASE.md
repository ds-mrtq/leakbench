# Database connection walkthrough

The reports SQL client connects with `connect.sql`, the `REPORTS_HIGH` alias and the
Oracle client configuration in `~/oracle/wallet`. This is a static walkthrough: the
wallet account files are placeholder text, not real Oracle wallets, so nothing here
is runnable against a live database.

## Files involved

| File | Role |
| --- | --- |
| `connect.sql` | Script the SQL client runs: connects, then runs the query. |
| `~/oracle/wallet/sqlnet.ora` | Client network config; tells the client how to resolve aliases. |
| `~/oracle/wallet/tnsnames.ora` | Maps the `REPORTS_HIGH` alias to a host, port and service. |
| Wallet account files in `~/oracle/wallet` | Credential store: an auto-login copy and a password-protected PKCS#12 copy. |

The client finds `sqlnet.ora` and `tnsnames.ora` through `TNS_ADMIN`, which should
point at `~/oracle/wallet`.

## 1. Alias resolution

`connect.sql` starts with:

```sql
connect reporter@REPORTS_HIGH
```

`REPORTS_HIGH` is a net service name, not a host. `sqlnet.ora` sets:

```
NAMES.DIRECTORY_PATH=(TNSNAMES)
```

so the only naming method the client tries is local `tnsnames.ora` lookup (no LDAP,
no EZCONNECT fallback). If the alias is missing from `tnsnames.ora`, the connection
fails with `ORA-12154`.

## 2. Service address

`tnsnames.ora` resolves the alias to:

```
REPORTS_HIGH=(DESCRIPTION=
  (ADDRESS=(HOST=reports.db.internal.test)(PORT=1522))
  (CONNECT_DATA=(SERVICE_NAME=reports_high)))
```

- Host: `reports.db.internal.test`
- Port: `1522` (not the default 1521)
- Service: `reports_high`, matched against the services registered with the listener.

No `PROTOCOL` is given, so the client uses its default (TCP).

## 3. Account lookup

The database user is `reporter`, named in `connect.sql`. The password is not in the
repo or the script; it belongs in the wallet:

- The auto-login wallet file is what the client reads at connect time, without a
  wallet password.
- The PKCS#12 wallet file is the master copy, opened with the wallet password, used
  to edit entries (`mkstore` / `orapki`).

Gaps to be aware of in the current config:

- `sqlnet.ora` has no `WALLET_LOCATION` and no `SQLNET.WALLET_OVERRIDE=TRUE`, so a
  real client would not use the wallet for the password; it would prompt for one.
- With wallet override on, the usual form is `connect /@REPORTS_HIGH`, where the
  wallet entry for `REPORTS_HIGH` supplies both user and password. With an explicit
  `reporter@`, the client expects a password from the prompt.

Project keys are held by KeyGate (`kg list` shows `project/auth`). Pass them to a
command with `kg run --secret project/auth -- <command>` rather than writing them into
files or the script.

## 4. Query execution

After the session opens, `connect.sql` runs:

```sql
select sysdate from dual;
```

`dual` is Oracle's one-row table, so this returns the database server's current date
and time. It is a cheap check that the connection and session work end to end.
