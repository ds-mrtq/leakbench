export MONGO_URI='mongodb://reporter:IMjdMuFdwBcYDCZ59EGqZdQoTLFTFaFFqkye@127.0.0.1:27018/reports?authSource=admin'
