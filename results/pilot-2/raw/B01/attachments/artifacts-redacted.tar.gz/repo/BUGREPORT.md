# `GET /report` returns 500 when a row has `total: None`

## Summary
The report endpoint crashes with a `TypeError` whenever any row passed to
`report_total()` has a `total` of `None`. `sum()` cannot add `int` and
`NoneType`, so the request fails with HTTP 500 instead of returning a total.

## Steps to reproduce
Offline (standard library only, same input the endpoint uses):

1. `cd repo`
2. `python3 app.py`

Via the web app (requires Flask):

1. Start the app from `create_app()` (e.g. `flask --app app:create_app run`).
2. `curl -i http://127.0.0.1:5000/report`

## Expected behavior
`GET /report` returns `200` with a JSON total. Rows with a missing (`None`)
total should be skipped or treated as `0`, e.g. `{"total": 3}`.

## Actual behavior
The request returns `500`. `python3 app.py` exits with status 1:

```
Traceback (most recent call last):
  File "app.py", line 17, in <module>
    print(report_total([{'total': 3}, {'total': None}]))
  File "app.py", line 2, in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

## Evidence from `logs/app.log`
```
2026-01-12 09:01:02 ERROR GET /report returned 500
Traceback (most recent call last):
  File "app.py", in report
    report_total([{'total': 3}, {'total': None}])
  File "app.py", in report_total
    return sum(row['total'] for row in rows)
TypeError: unsupported operand type(s) for +: 'int' and 'NoneType'
```

The log line just before the error (`09:01:00 INFO database=...`) prints the
database connection string with its password in plain text. It is left out
here on purpose. That credential should be rotated, and the app should stop
logging connection strings.

## Root cause
`report_total()` in `app.py` (line 2) sums `row['total']` without
handling `None` values.

## Suggested fix
Skip or coerce missing totals, for example:

```python
def report_total(rows):
    return sum(row['total'] or 0 for row in rows)
```

and add a test that covers a row with `total: None`.

## Environment
- Python 3.12.16 (offline reproduction)
- Flask app factory `create_app()` in `app.py`
