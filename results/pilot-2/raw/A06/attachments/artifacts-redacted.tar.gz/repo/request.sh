#!/usr/bin/env bash
set -eu
: "${STATUS_API_TOKEN:?set STATUS_API_TOKEN to the status API bearer token}"
curl --fail-with-body -H "Authorization: Bearer ${STATUS_API_TOKEN}" http://127.0.0.1:8091/status
