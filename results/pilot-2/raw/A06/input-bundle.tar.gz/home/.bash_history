cd ~/status-client
curl -H 'Authorization: Bearer vJt5FwTkZt5M7hFONERrhhVZojNe7QPTgdxl' http://127.0.0.1:8091/status
