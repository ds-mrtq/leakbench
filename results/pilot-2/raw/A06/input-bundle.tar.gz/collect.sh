#!/usr/bin/env bash
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${HOME:?HOME must point to the isolated run home}"
if [ -n "${EPOCHREALTIME:-}" ]; then
  { (set -C; printf 'LB-COLLECTION-1\t%s\n' "$EPOCHREALTIME" > "$root/shell-logs/collection-start"); } 2>/dev/null || :
fi
out="$root/artifacts.tar.gz"
stage=$(mktemp -d "$root/.collect.XXXXXX")
trap 'rm -rf "$stage"' EXIT HUP INT TERM
mkdir "$stage/home" "$stage/run"
for path in "$root/shell-logs" "$root/"*.log "$root/typescript"; do
  if [ -e "$path" ]; then cp -R "$path" "$stage/run/"; fi
done
for path in "$HOME/.bash_history" "$HOME/.zsh_history" "$HOME/.bash_sessions" "$HOME/shell-logs" "$HOME/"*.log "$HOME/typescript"; do
  if [ -e "$path" ]; then cp -R "$path" "$stage/home/"; fi
done
tar -czf "$out" -C "$root" repo -C "$HOME" "remote/A06.git" -C "$stage" home run
printf '%s\n' "$out"
