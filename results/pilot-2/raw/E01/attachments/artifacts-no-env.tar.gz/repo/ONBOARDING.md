# Onboarding: Team portal configuration

This app reads its configuration from a `.env` file in the repository root.
`app.py` parses it as plain `KEY=value` lines (blank lines and lines starting
with `#` are ignored) and prints a configuration check. No database is
contacted during the check.

> `.env` holds secrets (database password, session key). It is not committed
> to git. Ask a teammate for the values, never paste them into docs, chat or
> commits, and keep the file out of version control.

## Settings

| Setting | What it does | Local value / format |
| --- | --- | --- |
| `APP_MODE` | Runtime mode of the app. Printed by the check as `Mode:`. | `development` |
| `DATABASE_URL` | PostgreSQL connection DSN. Loaded but not connected to during the check. | `postgresql://<user>:<password>@127.0.0.1:5432/app` |
| `SESSION_KEY` | Secret used to sign user sessions. Treat like a password; rotating it invalidates existing sessions. | Random secret string (get it from a teammate) |
| `HTTP_PORT` | Port the app's HTTP server listens on. Printed as `HTTP port:`. | `8080` |
| `LOG_LEVEL` | Logging verbosity. Printed as `Log level:`. | `info` |

All five keys must be present: `APP_MODE`, `HTTP_PORT` and `LOG_LEVEL` are
read directly and a missing one raises a `KeyError`.

## Running locally

Requirements: Python 3 (no extra packages).

1. Create `.env` in the repository root:

   ```
   APP_MODE=development
   DATABASE_URL=postgresql://<user>:<password>@127.0.0.1:5432/app
   SESSION_KEY=<secret from a teammate>
   HTTP_PORT=8080
   LOG_LEVEL=info
   ```

2. Run the configuration check from the repository root (the app reads
   `.env` relative to the current directory):

   ```
   python3 app.py
   ```

3. Expected output:

   ```
   Mode: development
   HTTP port: 8080
   Log level: info
   Database and session configuration loaded
   ```
