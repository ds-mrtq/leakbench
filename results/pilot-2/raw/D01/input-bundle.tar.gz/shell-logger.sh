# Sourced by Bash startup files and BASH_ENV.
if [[ ${BASH_VERSINFO[0]:-0} -lt 5 || -z ${LB_RUN_ROOT:-} || ${_LB_CAPTURE_PID:-} == "$BASHPID" ]]; then
  return 0
fi
if ! command -v tee >/dev/null 2>&1; then return 0; fi
if ! tee --output-error=warn-nopipe </dev/null >/dev/null 2>&1; then return 0; fi
if ! mkdir -p -- "$LB_RUN_ROOT/shell-logs" 2>/dev/null; then return 0; fi
_LB_CAPTURE_PID=$BASHPID
_LB_CAPTURE_BASE="$LB_RUN_ROOT/shell-logs/bash-$BASHPID-$EPOCHREALTIME"
_lb_capture_record() {
  { printf 'LB-SHELL-1\t%s\t%s\t%s\n' "$EPOCHREALTIME" "$1" "$2"; } 2>/dev/null >> "$3" || :
  return 0
}
_lb_capture_stream() {
  local line source_text keep=0
  while IFS= read -r line || [[ -n $line ]]; do
    if [[ $1 == command ]]; then
      if [[ $line == +*LB-TRACE$'\t'* ]]; then
        source_text=${line#*LB-TRACE$'\t'}
        source_text=${source_text%%$'\t'*}
        line=${line#*LB-TRACE$'\t'}
        line=${line#*$'\t'}
        keep=1
        case " $source_text " in
          *"/.profile"*|*" .profile "*|\
          *"/.bashrc"*|*" .bashrc "*|\
          *"/.bash_profile"*|*" .bash_profile "*|\
          *"/.bash_login"*|*" .bash_login "*|\
          *"/.leakbench-shell-init"*|*" .leakbench-shell-init "*|\
          *"/env.sh"*|*" env.sh "*|\
          *"/shell-logger.sh"*|*" shell-logger.sh "*|\
          *"/etc/profile"*|*"/etc/bash.bashrc"*) keep=0 ;;
        esac
      fi
      [[ $keep == 1 ]] || continue
    fi
    _lb_capture_record "$1" "$line" "$2"
  done
  return 0
}
if [[ ${0##*/} == collect.sh ]]; then
  { (set -C; printf 'LB-COLLECTION-1\t%s\n' "$EPOCHREALTIME" > "$LB_RUN_ROOT/shell-logs/collection-start"); } 2>/dev/null || :
fi
exec {_LB_CAPTURE_OUT}>&1 {_LB_CAPTURE_ERR}>&2
exec > >(
  exec 1>&"$_LB_CAPTURE_OUT" 2>/dev/null
  exec {_LB_CAPTURE_OUT}>&- {_LB_CAPTURE_ERR}>&-
  tee --output-error=warn-nopipe >(exec >/dev/null 2>&1; _lb_capture_stream stdout "$_LB_CAPTURE_BASE.stdout.lb-log")
)
exec 2> >(
  exec 1>&"$_LB_CAPTURE_ERR" 2>/dev/null
  exec {_LB_CAPTURE_OUT}>&- {_LB_CAPTURE_ERR}>&-
  tee --output-error=warn-nopipe >(exec >/dev/null 2>&1; _lb_capture_stream stderr "$_LB_CAPTURE_BASE.stderr.lb-log")
)
exec {_LB_CAPTURE_OUT}>&- {_LB_CAPTURE_ERR}>&-
if [[ $- != *x* ]]; then
  exec {_LB_CAPTURE_TRACE}> >(exec >/dev/null 2>&1; _lb_capture_stream command "$_LB_CAPTURE_BASE.commands.lb-log")
  BASH_XTRACEFD=$_LB_CAPTURE_TRACE
  PS4=$'+LB-TRACE\t${BASH_SOURCE[*]}\t'
  set -x
fi
